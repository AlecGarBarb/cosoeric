package com.example.games

import android.content.Context
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*


class MainActivity : AppCompatActivity() {

    var player = 1
    var p1 = ArrayList<Int>()
    var p2 = ArrayList<Int>()
    var emptyCells = ArrayList<Int>()
    var cont1 = 0
    var cont2 = 0
    var autoplay = false;


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun gameOn(buttonCode:Int, selectedButton: Button){

        if(player == 1){
            selectedButton.text= "X"
            selectedButton.setBackgroundResource(R.color.blue)
            p1.add(buttonCode)
            player = 2
        }else if(player==2){
            selectedButton.text= "O"
            selectedButton.setBackgroundResource(R.color.green)
            p2.add(buttonCode)
            player = 1
        }


        selectedButton.isEnabled = false
    }

    fun autoPlay(){
        var rndm: Int
        var txt: String
        var colorsito1: Int
        var colorsito2: Int
        emptyCells.addAll(p2)
        emptyCells.addAll(p1)
        rndm =(1..9).random()
        while((emptyCells.contains(rndm))){
            rndm =(1..9).random()
        }

        if(player ==1){
            p1.add(rndm)
            player = 2
            txt = "X"
            colorsito2 = 255
            colorsito1 = 0

        }else{
            p2.add(rndm)
            player = 1
            txt= "O"
            colorsito2 = 0
            colorsito1 = 255

        }

                when(rndm){
                    1 ->{
                        button.text= txt
                        button.setBackgroundColor(Color.rgb(0, colorsito1, colorsito2))
                        button.isEnabled = false
                    }
                    2 ->  {
                        button2.text= txt
                        button2.setBackgroundColor(Color.rgb(0, colorsito1, colorsito2))
                        button2.isEnabled = false
                    }
                    3 -> {
                        button3.text= txt
                        button3.setBackgroundColor(Color.rgb(0, colorsito1, colorsito2))
                        button3.isEnabled = false
                    }
                    4 ->  {
                        button4.text= txt
                        button4.setBackgroundColor(Color.rgb(0, colorsito1, colorsito2))
                        button4.isEnabled = false
                    }
                    5 ->{
                        button5.text= txt
                        button5.setBackgroundColor(Color.rgb(0, colorsito1, colorsito2))
                        button5.isEnabled = false
                    }
                    6 ->{
                        button6.text= txt
                        button6.setBackgroundColor(Color.rgb(0, colorsito1, colorsito2))
                        button6.isEnabled = false
                    }
                    7 ->{
                        button7.text= txt
                        button7.setBackgroundColor(Color.rgb(0, colorsito1, colorsito2))
                        button7.isEnabled = false
                    }
                    8 ->{
                        button8.text= txt
                        button8.setBackgroundColor(Color.rgb(0, colorsito1, colorsito2))
                        button8.isEnabled = false
                    }
                    9 -> {
                        button9.text = txt
                        button9.setBackgroundColor(Color.rgb(0, colorsito1, colorsito2))
                        button9.isEnabled = false
                    }
            }



    }

    fun andTheWinneris(){
        var win = 0


        if(p1.contains(1)&&p1.contains(2) &&p1.contains(3)) win=1

        if(p2.contains(1)&&p2.contains(2) &&p2.contains(3)) win=2

        if(p1.contains(4)&&p1.contains(5) &&p1.contains(6)) win=1

        if(p2.contains(4)&&p2.contains(5) &&p2.contains(6)) win=2

        if(p1.contains(7)&&p1.contains(8) &&p1.contains(9)) win=1

        if(p2.contains(7)&&p2.contains(8) &&p2.contains(9)) win=2

        if(p1.contains(1)&&p1.contains(4) &&p1.contains(7)) win=1

        if(p2.contains(1)&&p2.contains(4) &&p2.contains(7)) win=2

        if(p1.contains(2)&&p1.contains(5) &&p1.contains(8)) win=1

        if(p2.contains(2)&&p2.contains(5) &&p2.contains(8)) win=2

        if(p1.contains(3)&&p1.contains(6) &&p1.contains(9)) win=1

        if(p2.contains(3)&&p2.contains(6) &&p2.contains(9)) win=2

        if(p1.contains(1)&&p1.contains(5) &&p1.contains(9)) win=1

        if(p2.contains(1)&&p2.contains(5) &&p2.contains(9)) win=2

        if(p1.contains(7)&&p1.contains(5) &&p1.contains(3)) win=1

        if(p2.contains(7)&&p2.contains(5) &&p2.contains(3)) win=2

        if(win ==1) cont1+=1
        if(win == 2) cont2+=1
        if(win !=0){
            Toast.makeText(this,
                "And the WINNER IS PLAYER $win", Toast.LENGTH_SHORT).show()
            resetGame()


        }


        score.setText("$cont1 - $cont2")


    }

    fun resetGame(){
        player = 1
        p1.clear()
        p2.clear()

        button.text= ""
        button.setBackgroundResource(R.color.white)
        button2.text= ""
        button2.setBackgroundResource(R.color.white)
        button3.text= ""
        button3.setBackgroundResource(R.color.white)
        button4.text= ""
        button4.setBackgroundResource(R.color.white)
        button5.text= ""
        button5.setBackgroundResource(R.color.white)
        button6.text= ""
        button6.setBackgroundResource(R.color.white)
        button7.text= ""
        button7.setBackgroundResource(R.color.white)
        button8.text= ""
        button8.setBackgroundResource(R.color.white)
        button9.text= ""
        button9.setBackgroundResource(R.color.white)

        button.isEnabled = true
        button.isEnabled = true
        button2.isEnabled = true
        button3.isEnabled = true
        button4.isEnabled = true
        button5.isEnabled = true
        button6.isEnabled = true
        button7.isEnabled = true
        button8.isEnabled = true
        button9.isEnabled = true


    }

    fun select(view: View) {
        val selectedButton = view as Button
        var buttonCode = 0

        when(selectedButton.id){

            R.id.button -> buttonCode =1
            R.id.button2 -> buttonCode =2
            R.id.button3 -> buttonCode =3
            R.id.button4 -> buttonCode =4
            R.id.button5 -> buttonCode =5
            R.id.button6 -> buttonCode =6
            R.id.button7 -> buttonCode =7
            R.id.button8 -> buttonCode =8
            R.id.button9 -> buttonCode =9
            R.id.buttonReset -> buttonCode = 10
            R.id.buttonAuto->  buttonCode = 11

        }

        if(buttonCode == 10){
            resetGame()
        }else if(buttonCode == 11){
            autoPlay()
        }else {
            gameOn(buttonCode, selectedButton)
        }
        andTheWinneris()

    }


}
